// src/ManualInput.js
import axios from 'axios'; // Import axios for making HTTP requests
import React, { useState } from 'react';

const ManualInput = () => {
    // State to track the manual input form data
    const [formData, setFormData] = useState({
        energyUsage: '',
        carbonEmissions: '',
        wasteManagement: '',
        employeeDiversity: '',
        governanceScore: '',
    });
    const [message, setMessage] = useState('');

    // Function to handle form input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,  // Dynamically update form data based on input name
        });
    };

    // Function to handle form submission and send data to backend
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Make POST request to backend to save the form data
            const response = await axios.post('http://localhost:5000/api/esg-data', formData);
            setMessage(response.data.message);  // Set success message from backend response
        } catch (error) {
            console.error('Error submitting form data:', error);
            setMessage('Error submitting data. Please try again.');
        }
    };

    return (
        <div>
            <h2>Manual ESG Data Input</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Energy Usage (kWh):
                    <input 
                        type="number" 
                        name="energyUsage" 
                        value={formData.energyUsage} 
                        onChange={handleChange} 
                        required 
                    />
                </label>
                <label>
                    Carbon Emissions (tons):
                    <input 
                        type="number" 
                        name="carbonEmissions" 
                        value={formData.carbonEmissions} 
                        onChange={handleChange} 
                        required 
                    />
                </label>
                <label>
                    Waste Management (% recycled):
                    <input 
                        type="number" 
                        name="wasteManagement" 
                        value={formData.wasteManagement} 
                        onChange={handleChange} 
                        required 
                    />
                </label>
                <label>
                    Employee Diversity (%):
                    <input 
                        type="number" 
                        name="employeeDiversity" 
                        value={formData.employeeDiversity} 
                        onChange={handleChange} 
                        required 
                    />
                </label>
                <label>
                    Governance Score (1-10):
                    <input 
                        type="number" 
                        name="governanceScore" 
                        value={formData.governanceScore} 
                        onChange={handleChange} 
                        required 
                    />
                </label>
                <button type="submit">Submit</button>
            </form>
            {message && <p>{message}</p>}  {/* Show success/error message */}
        </div>
    );
};

export default ManualInput;



