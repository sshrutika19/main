// src/FileUpload.js
import React, { useState } from 'react';

const FileUpload = () => {
    const [file, setFile] = useState(null);  // State to track the uploaded file
    const [message, setMessage] = useState('');  // State for any messages

    // Function to handle file selection
    const handleFileChange = (e) => {
        setFile(e.target.files[0]);  // Set selected file in state
    };

    // Function to handle file upload (without backend yet)
    const handleUpload = () => {
        if (!file) {
            setMessage('Please select a file to upload.');
            return;
        }

        setMessage(`File "${file.name}" uploaded successfully!`);
    };

    return (
        <div>
            <h2>Upload ESG Data File</h2>
            <input 
                type="file" 
                onChange={handleFileChange}  // Capture selected file
                accept=".csv, .xlsx"  // Only allow CSV and Excel files
            />
            <button onClick={handleUpload}>Upload</button>
            {message && <p>{message}</p>}  {/* Show upload success or error message */}
        </div>
    );
};

export default FileUpload;
