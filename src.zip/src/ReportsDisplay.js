import axios from 'axios';
import React, { useEffect, useState } from 'react';

function ReportsDisplay() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    async function fetchReports() {
      try {
        const response = await axios.get('http://localhost:5000/reports');
        setReports(response.data);
      } catch (error) {
        console.error('Error fetching reports:', error);
      }
    }
    fetchReports();
  }, []);

  return (
    <div>
      <h2>ESG Reports</h2>
      <ul>
        {reports.map((report) => (
          <li key={report._id}>
            <strong>Company Name:</strong> {report.companyName} <br />
            <strong>Environmental Score:</strong> {report.environmentalScore} <br />
            <strong>Social Score:</strong> {report.socialScore} <br />
            <strong>Governance Score:</strong> {report.governanceScore} <br />
            <strong>Report Date:</strong> {new Date(report.reportDate).toLocaleDateString()} <br />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ReportsDisplay;
