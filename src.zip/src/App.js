// src/App.js
import React from 'react';
import FileUpload from './FileUpload';
import ManualInput from './ManualInput';
import ReportsDisplay from './ReportsDisplay'; // Import new component

function App() {
  return (
    <div className="App">
      <h1>ESG Report Generator</h1>
      <FileUpload />
      <ManualInput />
      <ReportsDisplay /> {/* Add ReportsDisplay component */}
    </div>
  );
}

export default App;
